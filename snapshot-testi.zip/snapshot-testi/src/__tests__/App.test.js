import React from 'react';
import App from '../App';
import { create } from 'react-test-renderer';
 
describe('Snapshot-testi', () => {
    test('testataan App', () => {
        let tree = create(<App />)
        expect(tree.toJSON()).toMatchSnapshot();
    })
})